package model;

public class Model {
    public static final int VAZIO = 2;
    public static final int O = 1;
    public static final int X = 3;

    public static final int LINHAS = 3;
    public static final int COLUNAS = 3;

    private int[][] tabuleiro;

    public Model() {
        tabuleiro = new int[LINHAS][COLUNAS];
        reiniciarTabuleiro();
    }
    
      public int[][] getTabuleiro() {
        return tabuleiro;
    }
      
    public void reiniciarTabuleiro() {
        for (int i = 0; i < LINHAS; i++) {
            for (int j = 0; j < COLUNAS; j++) {
                tabuleiro[i][j] = VAZIO;
            }
        }
    }

  
   public boolean fazerJogada(int linha, int coluna, int jogador) {
        if (linha < 0 || linha >= LINHAS || coluna < 0 || coluna >= COLUNAS || tabuleiro[linha][coluna] != VAZIO) {
            return false;
        }
        tabuleiro[linha][coluna] = jogador;
        return true;
    }

    public boolean verificarVitoria(int jogador) {
        for (int i = 0; i < LINHAS; i++) {
            int produto = 1;
            for (int j = 0; j < COLUNAS; j++) {
                produto *= tabuleiro[i][j];
            }
            if (produto == jogador * jogador * jogador) {
                return true;
            }
        }

        for (int j = 0; j < COLUNAS; j++) {
            int produto = 1;
            for (int i = 0; i < LINHAS; i++) {
                produto *= tabuleiro[i][j];
            }
            if (produto == jogador * jogador * jogador) {
                return true;
            }
        }

        int diagonalPrincipal = tabuleiro[0][0] * tabuleiro[1][1] * tabuleiro[2][2];
        int diagonalSecundaria = tabuleiro[0][2] * tabuleiro[1][1] * tabuleiro[2][0];
        return (diagonalPrincipal == jogador * jogador * jogador || diagonalSecundaria == jogador * jogador * jogador);
    }

    public boolean verificarEmpate() {
        for (int i = 0; i < LINHAS; i++) {
            for (int j = 0; j < COLUNAS; j++) {
                if (tabuleiro[i][j] == VAZIO) {
                    return false;
                }
            }
        }
        return true;
    }

    public int minimax(int profundidade, int jogador) {
        if (verificarVitoria(O)) {
            return 1;
        }
        if (verificarVitoria(X)) {
            return -1;
        }
        if (verificarEmpate()) {
            return 0;
        }

        if (jogador == O) {
            int melhorValor = Integer.MIN_VALUE;
            for (int i = 0; i < LINHAS; i++) {
                for (int j = 0; j < COLUNAS; j++) {
                    if (tabuleiro[i][j] == VAZIO) {
                        tabuleiro[i][j] = O;
                        int valor = minimax(profundidade + 1, X);
                        tabuleiro[i][j] = VAZIO;
                        melhorValor = Math.max(melhorValor, valor);
                    }
                }
            }
            return melhorValor;
        } else {
            int melhorValor = Integer.MAX_VALUE;
            for (int i = 0; i < LINHAS; i++) {
                for (int j = 0; j < COLUNAS; j++) {
                    if (tabuleiro[i][j] == VAZIO) {
                        tabuleiro[i][j] = X;
                        int valor = minimax(profundidade + 1, O);
                        tabuleiro[i][j] = VAZIO;
                        melhorValor = Math.min(melhorValor, valor);
                    }
                }
            }
            return melhorValor;
        }
    }

    public void jogadaComputador() {
        int melhorValor = Integer.MIN_VALUE;
        int melhorLinha = -1;
        int melhorColuna = -1;

        for (int i = 0; i < LINHAS; i++) {
            for (int j = 0; j < COLUNAS; j++) {
                if (tabuleiro[i][j] == VAZIO) {
                    tabuleiro[i][j] = O;
                    int valor = minimax(0, X);
                    tabuleiro[i][j] = VAZIO;
                    if (valor > melhorValor) {
                        melhorValor = valor;
                        melhorLinha = i;
                        melhorColuna = j;
                    }
                }
            }
        }

        fazerJogada(melhorLinha, melhorColuna, O);
    }
}
