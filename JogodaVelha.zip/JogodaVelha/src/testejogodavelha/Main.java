import java.util.Scanner;
import controller.Controller;
import model.Model;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Controller controller = new Controller();
        int jogadorAtual = Model.X;

        while (true) {
            controller.exibirTabuleiro();
            if (jogadorAtual == Model.X) {
                System.out.println("Sua vez, jogador X.");
                System.out.print("Informe a linha (0-2): ");
                int linha = scanner.nextInt();
                System.out.print("Informe a coluna (0-2): ");
                int coluna = scanner.nextInt();

                if (controller.fazerJogada(linha, coluna, jogadorAtual)) {
                    if (controller.verificarVitoria(jogadorAtual)) {
                        System.out.println("Parabens, você venceu!");
                        break;
                    } else if (controller.verificarEmpate()) {
                        System.out.println("Empate!");
                        break;
                    }
                    jogadorAtual = Model.O;
                } else {
                    System.out.println("Jogada invalida. Tente novamente.");
                }
            } else {
                System.out.println("Vez do computador (O).");
                controller.jogadaComputador();
                if (controller.verificarVitoria(Model.O)) {
                    System.out.println("O computador venceu!");
                    break;
                } else if (controller.verificarEmpate()) {
                    System.out.println("Empate!");
                    break;
                }
                jogadorAtual = Model.X;
            }
        }

        controller.exibirTabuleiro();
        scanner.close();
    }
}
