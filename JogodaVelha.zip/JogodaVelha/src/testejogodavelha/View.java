package view;

import model.Model;

public class View {
    public void exibirTabuleiro(int[][] tabuleiro) {
        for (int i = 0; i < Model.LINHAS; i++) {
            for (int j = 0; j < Model.COLUNAS; j++) {
                if (tabuleiro[i][j] == Model.O) {
                    System.out.print("O ");
                } else if (tabuleiro[i][j] == Model.X) {
                    System.out.print("X ");
                } else {
                    System.out.print("- ");
                }
            }
            System.out.println();
        }
    }
}

