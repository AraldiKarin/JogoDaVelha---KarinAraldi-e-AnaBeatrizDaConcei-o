package controller;

import model.Model;
import view.View;

public class Controller {
    private Model jogo;
    private View view;

    public Controller() {
        this.jogo = new Model();
        this.view = new View();
    }

    public void reiniciarTabuleiro() {
        jogo.reiniciarTabuleiro();
    }

    public void exibirTabuleiro() {
        view.exibirTabuleiro(jogo.getTabuleiro());
    }

    public boolean fazerJogada(int linha, int coluna, int jogador) {
        return jogo.fazerJogada(linha, coluna, jogador);
    }

    public boolean verificarVitoria(int jogador) {
        return jogo.verificarVitoria(jogador);
    }

    public boolean verificarEmpate() {
        return jogo.verificarEmpate();
    }

    public void jogadaComputador() {
        jogo.jogadaComputador();
    }
}

